This driver is required on Windows 7 only, to create the Serial Port. 
Do not install on Windows 10!